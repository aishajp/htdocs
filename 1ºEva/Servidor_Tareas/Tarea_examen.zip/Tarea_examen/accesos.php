<?php 
session_start(); 
/*conectarse a la base de datos*/ 
require_once "login.php";  
$Nombre = $_POST['Nombre']; 
$Clave = $_POST['Clave']; 
$connection = new mysqli($hn, $un, $pw, $db); 


if ($connection->connect_error) { 
    die("Connection failed: ". $connection->connect_error); 
}else{ 
    $sql = "SELECT Nombre, Clave FROM Nombre WHERE Nombre = '$Nombre' AND Clave = '$Clave'"; 
    $result = $connection->query($sql); //llamo a la sentencia de SELECT  
    $uValido = $result ->fetch_assoc()['Nombre']; 
    $result -> data_seek(0); 
    $pValido = $result ->fetch_assoc()['Clave']; 

    if($uValido == $Nombre && $pValido == $Clave){ 
        echo "Has iniciado correctamente"; 
    }else{ 
        echo "Nombre o clave incorrectos"; 
    } 
    $connection->close(); 
} 