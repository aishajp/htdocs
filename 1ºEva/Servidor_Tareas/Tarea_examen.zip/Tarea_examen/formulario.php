<!DOCTYPE html> 
<html lang="en"> 
<head> 
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>simon</title> 
</head> 

<body> 

    <h1>Inicio de Sesión</h1> 
    <form method="POST" action="accesos.php"> 
        <label for="Nombre">Usuario:</label><br> 
        <input type="text" name="Nombre"/><br> 
        <label for="Clave">Contraseña:</label><br> 
        <input type="password" name="Clave"/><br> 
        <input type="submit" name="enviar" value="Iniciar sesion" href="jugar.php"/> 
    </form> 
</body> 
</html>