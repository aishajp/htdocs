<?php
$hn="localhost";
$db="simon";
$un="root";
$pw="";
?>