class CalculoIMC {
    constructor(nombre, imc) {
        this.nombre = nombre;
        this.imc = imc;
    }
}